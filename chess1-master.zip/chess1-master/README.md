# chess1
chess engine that always takes your piece if possible
enter /index.html for level 1
enter /index2.html for level 2
Level 1:chess engine that always takes your piece if possible
Level 2:Looks two moves ahead.
